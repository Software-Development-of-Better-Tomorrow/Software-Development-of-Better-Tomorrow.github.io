// import public objects from other modules
import { me as my_description } from "./about/me";

// import css stylesheets
import "./css/index.css";


function useMe(me: object, count: number) : void {
    document.body.innerHTML = "";

    for(let i=1; i <= count; i++) {
        document.body.innerHTML +=   `
                                        <div class="content">`+
                                                        "[ Business Card #" + i + "]" + "<br /><br />" + 
                                                        my_description.name + "<br />" +
                                                        my_description.surname + "<br />" +
                                                        my_description.occupation + "<br />" +
                                                        "<strong>" + my_description.website + "</strong>" + "<br />" +
                                        `</div>
                                    `;
    }
}




//entry point to the application
useMe(my_description, 2);  // change this number to see immediate changes in the browser