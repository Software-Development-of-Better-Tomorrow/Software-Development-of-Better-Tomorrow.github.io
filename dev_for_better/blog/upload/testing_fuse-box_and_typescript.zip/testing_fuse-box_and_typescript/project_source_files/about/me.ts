// this is public object in TypeScript because we export it to project's global scope (this object is visible to the whole project) 
const me = {
    name: "Łukasz",
    surname: "Dąbrowski",
    occupation: "Software Engineer",
    website: "https://dabrowski-software-development.github.io"
};


// this is private object in TypeScript because we DO NOT export it to project's global scope (this object is visible only in this module) 
const myFamily = {
    insulting: "higly forbidden"
}



// set object to be exported
export { me }