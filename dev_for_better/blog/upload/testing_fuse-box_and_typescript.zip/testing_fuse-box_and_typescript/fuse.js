/**
    FuseBox official website:
                                http://fuse-box.org/        [ Ctrl + click to follow link ]
 */


// import required library ( FuseBox )
const { FuseBox, CSSPlugin, WebIndexPlugin, Sparky }  = require('fuse-box');



// define bundler's instance (FuseBox instance)
const fuse = FuseBox.init(
    {
        homeDir : "project_source_files",
        output : "dist/$name.js",
        plugins: [
            CSSPlugin(),
            WebIndexPlugin({path: "./"})
        ]
    }
);



// run development server [ express.js ]
fuse.dev(/* here come options */);



// configure bundle process 
fuse.bundle("main-page-bundle-js-file")  // this is how output file will be named
    .instructions("> *.ts")              // this FuseBox language instruction says "compile project's all TypeScript files and bundle them into 'main-page-bundle-js-file.js' file"
    .watch()                             // this line says to FuseBox "if any source file in the project has changed, re-bundle everything"
    .hmr();                              // this line says to FuseBox "after you have rebundled everything update automatically state in the browser,
                                        //  so that user don't have to press Ctrl+R or hit F5 in the browser



// this is task runner that automates common tasks, f.e. 'Clean Solution', 'Build Solution', 'Rebuild Solution', copy files to output.
// this is like Ant in Java.
Sparky.task("clean", () => {
  return Sparky.src("dist").clean("dist"); // you can read it as 'take dist folder and clean it'
});

Sparky.task("watch:images", () => {
  return Sparky.watch("**/*.+(svg|png|jpg|gif)", {base: "./src"}) // you can read it as 'watch if any file with these types has changed' ...
               .dest("./dist");                                   // and copy those changed files to dist folder
});

Sparky.task("default", ["clean", "watch:images"], () => {        // this line says 'run task default only after dependent tasks finished successfully in this provided order, i.e. clean, watch:images'
  fuse.run();                                                    // and this default task is 'run bundling process'
});